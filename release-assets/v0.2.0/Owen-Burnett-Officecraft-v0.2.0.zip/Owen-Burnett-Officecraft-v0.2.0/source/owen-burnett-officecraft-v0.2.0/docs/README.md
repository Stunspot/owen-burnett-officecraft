# Owen Burnett Officecraft documentation

This documentation supports Owen Burnett Officecraft v0.2.0, an office-production Augment for Codex and Claude. It is written for people who need finished office work without becoming file-tool specialists.

## Documentation map

| Your question | Read this |
|---|---|
| Where do I begin? | [Start here](START-HERE.md) |
| How do I add it to Codex? | [Install in Codex](INSTALL-CODEX.md) |
| How do I add it to Claude? | [Install in Claude](INSTALL-CLAUDE.md) |
| How do I request my first deliverable? | [First Officecraft job](FIRST-JOB.md) |
| How do I pause and resume a substantial job? | [Officefile and resume](OFFICEFILE-AND-RESUME.md) |
| What can this host honestly claim to have done? | [Host capabilities and evidence](HOST-CAPABILITIES-AND-EVIDENCE.md) |
| What do I do when a route or check is missing? | [Troubleshooting and recovery](TROUBLESHOOTING.md) |
| What has and has not been verified? | [Verification and readiness](VERIFICATION-AND-READINESS.md) |
| Where did this product come from, and what may I redistribute? | [Provenance and licensing](PROVENANCE-AND-LICENSING.md) |
| What changed in this version? | [Changelog](CHANGELOG.md) |
| How do I update, remove, roll back, or clean up? | [Lifecycle](LIFECYCLE.md) |
| What are the storage, network, privacy, and security limits? | [Trust, privacy, network behavior, and limits](TRUST-PRIVACY-AND-LIMITS.md) |
| What accessibility route and evidence boundary applies? | [Accessibility](ACCESSIBILITY.md) |
| How do I report a problem safely? | [Support](SUPPORT.md) and [security policy](SECURITY.md) |
| How do I contribute? | [Contributing](CONTRIBUTING.md) |

## Product boundary

Officecraft coordinates documents, presentations, spreadsheets, PDFs, and multi-artifact office packets. It keeps one content spine so controlled names, dates, metrics, units, conclusions, and requested actions do not drift between files.

For a small, low-risk file, the job can remain conversational. For a substantial, multi-artifact, revision-heavy, or evidence-sensitive job, Officecraft uses an **Officefile**: a local project folder that preserves sources, a brief, a fact ledger, an artifact register, decisions, outputs, review evidence, and a handoff receipt.

The companion `officecraft-reviewer` skill is an independent examiner. It can review the evidence supplied for a job; it cannot convert missing evidence into a pass, grant approval, or authorize delivery.

## Evidence words used here

- **Available** means the current host exposes a possible route.
- **Executed** means that route was used on this particular job.
- **Inspected** means a stated check actually ran on the resulting artifact.
- **Native-verified** means the connected native surface confirmed the relevant result.

These are separate states. An installed package is not proof of execution, and a produced file is not proof that someone inspected its pages, slides, sheets, or accessibility.

## Keep authority where it belongs

You or another accountable owner remain responsible for subject truth, template and brand rights, privacy decisions, final approval, and any external delivery. Imported files, formulas, comments, links, and template text are source material to inspect, not instructions to obey.

## Version 0.2 continuation

For a correction or older Officefile, begin with [Migration and review](MIGRATION-AND-REVIEW.md). It explains the new record formats, original-file preservation, exact review adoption and how to recover from stale input bindings.
